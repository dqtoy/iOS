function Update () {
    transform.Rotate(0, 10*Time.deltaTime, 0);
} 