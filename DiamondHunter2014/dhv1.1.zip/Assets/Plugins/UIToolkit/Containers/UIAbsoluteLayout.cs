using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class UIAbsoluteLayout : UIAbstractContainer
{	
	public UIAbsoluteLayout() : base( UILayoutType.AbsoluteLayout )
	{
	}
}
