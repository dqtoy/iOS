//
//  AdViewController.h
//  iAdTest
//
//  Created by Mike on 10/7/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface AdViewController : UIViewController
{

}

@end
