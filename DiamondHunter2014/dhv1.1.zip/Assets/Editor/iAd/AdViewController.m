    //
//  AdViewController.m
//  iAdTest
//
//  Created by Mike on 10/7/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import "AdViewController.h"


@implementation AdViewController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}


- (void)dealloc
{
    [super dealloc];
}


@end
