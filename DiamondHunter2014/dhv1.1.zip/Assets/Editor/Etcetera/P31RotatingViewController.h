//
//  P31RotatingViewController.h
//  EtceteraTest
//
//  Created by Mike on 10/3/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface P31RotatingViewController : UIViewController
{

}

@end
