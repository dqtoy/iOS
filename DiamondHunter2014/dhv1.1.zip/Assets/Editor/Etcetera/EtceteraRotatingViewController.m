    //
//  RotatingViewController.m
//  Unity-iPhone
//
//  Created by Mike on 10/27/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import "EtceteraRotatingViewController.h"


@implementation EtceteraRotatingViewController

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
	return YES;
}

@end
