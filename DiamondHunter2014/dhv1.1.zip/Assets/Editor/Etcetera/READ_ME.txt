Note for Unity 3.0 - 3.1 users:
For MSAA support, you will need to remove the current AppController.mm.patch file (which is for 3.2 and above), rename the
AppController.mm.patch.3.txt to AppController.mm.patch and uncomment the MSAA method in the EtceteraBinding.cs file.



Note for Unity 1.7 users:
For MSAA support, you will need to remove the current AppController.mm.patch file (which is for 3.2 and above), rename the
AppController.mm.patch.17.txt to AppController.mm.patch and uncomment the MSAA method in the EtceteraBinding.cs file.

