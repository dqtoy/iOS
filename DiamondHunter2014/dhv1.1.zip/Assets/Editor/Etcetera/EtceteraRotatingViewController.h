//
//  RotatingViewController.h
//  Unity-iPhone
//
//  Created by Mike on 10/27/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface EtceteraRotatingViewController : UIViewController
{

}

@end
