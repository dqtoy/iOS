//
//  P31RadialBackgroundView.h
//  P31AlertView
//
//  Created by Mike on 9/12/10.
//  Copyright 2010 Prime31 Studios. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface P31RadialBackgroundView : UIView
{

}

@end
